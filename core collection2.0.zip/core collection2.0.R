# Core Collection Construction and Evaluation System V1.0: edit the settings below, then run the entire script.
# 1. Paths and input files ------------------------------------------------
work_dir <- Sys.getenv("CORE_PROJECT_DIR", unset = "I:/Core collection2.0")
source(file.path(work_dir, "Core_collection_Functions.txt"), encoding = "UTF-8")
pheno_file <- file.path(work_dir, "Phenotype.csv")
geno_file <- file.path(work_dir, "Genotype.csv")
output_dir <- Sys.getenv("CORE_PROJECT_OUTPUT", unset = file.path(work_dir, "Core_Workflow_Results"))

# 2. Run mode, data types, and sampling strategies ------------------------
run_mode <- "all"      # all: sample and evaluate; sampling: sample only; evaluation: evaluate existing sample lists or parameter tables.
data_types <- c("pheno", "geno", "pheno_geno") # Select the data types to sample.
strategies <- "SVM"    # Use c("SVM", "RF", "LGBM") to run all three strategies.
pheno_sampling_mode <- "conservation"  # Controls the phenotypic objective for both P and PG. Use "breeding" for directional selection.

# P (phenotype), G (genotype), and PG (joint) use nested, multi-objective selection by default.
# The three strategies share the same objectives but use different model scores.
# Use ratio for phenotype-only or genotype-only sampling. For weight/grid alone, set data_types to "pheno_geno".
comparison_modes <- c("ratio", "weight")  # ratio: compare sampling proportions; weight: compare joint weights; grid: run all combinations.


# 3. Sampling proportions and joint weights -------------------------------
# 3.1 Sampling proportions to compare within each strategy
sample_ratios <- c(.80)

# 3.2 Fixed weights for comparing joint collections across sampling proportions
ratio_pheno_weight <- .50  # Fixed phenotypic weight for the PG ratio comparison; the genotypic weight is its complement.

# 3.3 Weight combinations for joint sampling
weight_sample_ratio <- .20  # Fixed sampling proportion for the PG weight comparison.
pheno_weights <- seq(.1, .9, .1)  # Phenotypic weights for weight and grid comparisons; 0.5 gives P5G5 (equal weights).

# 4. Evaluation modules (independent switches) ----------------------------
run_parameters <- TRUE  # Calculate and plot evaluation parameters from the original data and core sample lists.
run_membership <- TRUE  # Use the calculated parameters for membership function evaluation; this module can also run on its own.
run_pca <- TRUE         # Run PCA on the original genotype data and highlight accessions from each core sample list.
directions <- c(Ne = "+", Ho = "+", He = "+", I = "+", PIC = "+",
                Fis = "-", MD = "-", VD = "+", CR = "+", VR = "+")
membership_weights <- NULL  # Give each evaluation metric equal weight; these are not the phenotype/genotype sampling weights.
membership_group_by <- NULL  # Score each table separately. Set to "Ratio" to compare strategies within each sampling proportion.
# The original positive direction for VD favors variation enrichment; choose metric directions to suit the study objective.
core_files <- NULL  # In all mode, use the new sample lists. In evaluation mode, read existing lists according to comparison_modes.

# core_files <- c(MyCores = "I:/data/core_samples.csv")  # Custom sample list for evaluation mode only.
membership_files <- NULL  # To evaluate existing parameter tables only, set run_mode to "evaluation" and enable only run_membership.
# membership_files <- c(SamplingRatios = file.path(output_dir, "02_Core_Evaluation","01_Genetic_Parameters", "SamplingRatios_Parameters.csv"))

# 5. Output and execution -------------------------------------------------
figure_formats <- "png"  # Choose "png", "jpg", or "pdf"; use c("png", "jpg", "pdf") to export all three.
save_rds <- FALSE        # By default, the full sampling object is not saved and no run log is written.
seed <- 123L
install_missing <- TRUE  # Install missing R packages needed for this run; leave working packages unchanged.
analyses <- c(if (run_parameters) "parameters", if (run_membership) "membership", if (run_pca) "pca")
result <- CoreCollectionEvaluation(
  pheno_file = pheno_file, geno_file = geno_file, run_mode = run_mode,
  data_types = data_types, strategies = strategies, comparison_modes = comparison_modes,
  sample_ratios = sample_ratios, ratio_pheno_weight = ratio_pheno_weight,
  weight_sample_ratio = weight_sample_ratio, pheno_weights = pheno_weights,
  analyses = analyses, core_files = core_files, membership_files = membership_files,
  membership_directions = directions, membership_weights = membership_weights,
  membership_group_by = membership_group_by, output_dir = output_dir,
  seed = seed, save_rds = save_rds, figure_formats = figure_formats,
  install_missing = install_missing, pheno_sampling_mode = pheno_sampling_mode
)

