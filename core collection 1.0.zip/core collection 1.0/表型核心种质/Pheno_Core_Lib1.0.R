# ==============================================================================
# 脚本名称: Pheno_Core_Lib.R
# 功能描述: 整合SVM, RF, LGBM三种策略构建核心种质的函数库
# ==============================================================================

library(caret)
library(e1071)    # SVM
library(ranger)   # Random Forest
library(lightgbm) # LightGBM
library(dplyr)

# 核心构建函数
build_core_germplasm <- function(file_path, strategy = "SVM", sample_ratio = 0.2, seed = 123) {
  
  # --- Step 1: 数据准备 (逻辑与原脚本保持严格一致) ---
  # 读取数据，保留原始ID用于后续输出
  raw_data <- read.csv(file_path, header = TRUE)
  original_ids <- raw_data[, 1]  # 假设第一列是ID
  pheno.data <- raw_data[, -c(1:1)] # 去掉ID用于分析
  
  # 缺失值填补
  data <- pheno.data %>%
    mutate(across(where(is.numeric), ~ ifelse(is.na(.), mean(., na.rm = TRUE), .)))
  
  # 标准化
  preprocess <- preProcess(data, method = c("center", "scale"))
  data_scaled_df <- as.data.frame(predict(preprocess, data))
  
  # 变异度加权得分
  trait_weights <- apply(data_scaled_df, 2, sd)
  weighted_scores <- rowMeans(sweep(data_scaled_df, 2, trait_weights, `*`))
  data_scaled_df$Score <- scale(weighted_scores)
  
  # PCA降维
  pca_result <- prcomp(data_scaled_df[, !(colnames(data_scaled_df) %in% "Score")], center = TRUE, scale. = TRUE)
  explained_var <- summary(pca_result)$importance[2, ]
  num_components <- which(cumsum(explained_var) >= 0.95)[1]
  X_pca <- as.data.frame(pca_result$x[, 1:num_components])
  X_pca$Score <- data_scaled_df$Score
  
  # --- Step 2: 模型训练与排序 ---
  # [cite_start]设定种子，确保划分一致 [cite: 1, 4, 8]
  set.seed(seed) 
  trainIndex <- createDataPartition(X_pca$Score, p = 0.9, list = FALSE)
  X_train <- X_pca[trainIndex, 1:num_components]
  X_train$Score <- X_pca$Score[trainIndex]
  X_all <- X_pca[, 1:num_components]
  
  y_all_pred <- NULL
  
  # 根据策略选择模型
  if (strategy == "SVM") {
    # [cite_start]SVM 策略 [cite: 1, 2]
    svm_model <- train(
      Score ~ ., data = X_train,
      method = "svmRadial",
      trControl = trainControl(method = "cv", number = 10),
      tuneLength = 10
    )
    y_all_pred <- predict(svm_model, newdata = X_all)
    
  } else if (strategy == "RF") {
    # [cite_start]Random Forest 策略 [cite: 4, 5]
    rf_model <- train(
      Score ~ ., data = X_train,
      method = "ranger",
      trControl = trainControl(method = "cv", number = 10),
      tuneLength = 10
    )
    y_all_pred <- predict(rf_model, newdata = X_all)
    
  } else if (strategy == "LGBM") {
    # [cite_start]LightGBM 策略 [cite: 7, 8, 9]
    train_data <- lgb.Dataset(data = as.matrix(X_train[, 1:num_components]), label = X_train$Score)
    params <- list(
      objective = "regression", metric = "l2", boosting_type = "gbdt",
      num_leaves = 30, learning_rate = 0.05, feature_fraction = 0.9
    )
    lgb_model <- lgb.train(params = params, data = train_data, nrounds = 100, verbose = -1)
    y_all_pred <- predict(lgb_model, as.matrix(X_all))
  } else {
    stop("不支持的策略，请选择 'SVM', 'RF' 或 'LGBM'")
  }
  
  sorted_indices <- order(y_all_pred, decreasing = TRUE)
  
  # --- Step 3 & 4: 核心样本筛选 (高代表性 + 多样性增量) ---
  num_samples <- round(nrow(X_pca) * sample_ratio)
  init_num <- max(2, round(num_samples * 0.2)) # 保持原逻辑：先取目标数量的20%作为高代表性
  
  core_indices <- sorted_indices[1:init_num]
  
  # [cite_start]多样性增量法循环 [cite: 2, 3, 6, 10]
  while(length(core_indices) < num_samples) {
    remain <- setdiff(1:nrow(X_pca), core_indices)
    
    # 构建核心组与剩余组的合并矩阵用于计算距离
    curr_core_data <- X_pca[core_indices, 1:num_components, drop=FALSE]
    curr_remain_data <- X_pca[remain, 1:num_components, drop=FALSE]
    combined_data <- rbind(curr_core_data, curr_remain_data)
    
    dist_to_core <- as.matrix(dist(combined_data))
    
    # 提取剩余样本(行)到核心样本(列)的距离块
    # rows: (length(core)+1) to end; cols: 1 to length(core)
    dist_mat <- dist_to_core[(length(core_indices)+1):nrow(dist_to_core), 1:length(core_indices), drop=FALSE]
    
    min_dist <- apply(dist_mat, 1, min)
    next_idx <- remain[which.max(min_dist)]
    core_indices <- c(core_indices, next_idx)
  }
  
  # 返回结果：包含行号和对应的原始ID
  result <- list(
    row_indices = sort(core_indices), # 排序后的行号
    original_ids = original_ids[sort(core_indices)] # 对应的原始ID
  )
  return(result)
}