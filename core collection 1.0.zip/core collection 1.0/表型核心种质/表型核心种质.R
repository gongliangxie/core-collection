# ==============================================================================
# 脚本名称: Run_Analysis.R
# 功能描述: 调用Pheno_Core_Lib.txt，批量执行不同策略和比例，并保存结果表
# ==============================================================================
# 1. 设置工作目录和参数
setwd("F:/表型核心种质") # 请根据实际情况修改路径

# 2. 加载工具库
source("Pheno_Core_Lib1.0.R")
#加载数据
data_file <- "Phenotype.csv"

# 定义要运行的策略列表
strategies_to_run <- c("SVM")#抽样策略："SVM", "RF", "LGBM"

# 定义核心种质抽样比例列表 (例如: 10%, 20%, 30%)
ratios_to_run <- c(0.30) 

# 初始化结果列表
all_results <- list()
max_len <- 0 # 用于最后对齐表格

# 3. 循环执行任务
cat("开始执行核心种质构建任务...\n")

for (strat in strategies_to_run) {
  for (ratio in ratios_to_run) {
    
    cat(sprintf("正在运行策略: %s, 抽样比例: %.2f ... ", strat, ratio))
    
    # 调用核心函数
    # 注意：seed默认123，若需要改变随机性可在此修改参数
    res <- build_core_germplasm(data_file, strategy = strat, sample_ratio = ratio, seed = 123)
    
    # 构建列名，例如 SVM_10%
    col_name <- paste0(strat, "_", ratio * 100, "%")
    
    # 存储结果ID
    all_results[[col_name]] <- res$original_ids
    
    # 记录最大长度以便后续合并
    if (length(res$original_ids) > max_len) {
      max_len <- length(res$original_ids)
    }
    
    cat("完成! 选中数量:", length(res$original_ids), "\n")
  }
}

# 4. 将结果整理为表格并保存
# 由于不同比例选出的数量不同，需要用NA补齐短的列
result_df <- data.frame(matrix(ncol = length(all_results), nrow = max_len))
colnames(result_df) <- names(all_results)

for (name in names(all_results)) {
  ids <- all_results[[name]]
  # 补齐长度
  ids_padded <- c(ids, rep(NA, max_len - length(ids)))
  result_df[[name]] <- ids_padded
}

# 5. 导出CSV
output_filename <- paste0("Pheno_LGBM", ".csv")
write.csv(result_df, output_filename, row.names = FALSE, na = "")

cat("\n所有任务完成！结果已保存至:", output_filename, "\n")

