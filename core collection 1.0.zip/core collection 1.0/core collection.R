# ==============================================================================
# 核心种质构建主运行脚本
# 日常使用只需修改下面 1-4 部分。
# ==============================================================================

options(stringsAsFactors = FALSE)

# 1. 路径设置和输入文件
work_dir <- Sys.getenv(
  "CORE_WORK_DIR",
  unset = "I:/core collection 1.0"    #设置成实际路径
)
pheno_file <- file.path(work_dir, "Phenotype.csv")
geno_file <- file.path(work_dir, "Genotype.csv")
output_dir <- file.path(work_dir, "Core_Results")

library_files <- c(
  "Core_Common_Lib.txt",
  "Pheno_Core_Lib.txt",
  "Genotype_Core_Lib.txt",
  "Pheno-Geno_Core_Lib1.0.txt"
)
required_files <- c(library_files, basename(pheno_file), basename(geno_file))
missing_files <- required_files[
  !file.exists(file.path(work_dir, required_files))
]
if (length(missing_files) > 0L) {
  stop(
    paste("缺少文件：", paste(missing_files, collapse = ", ")),
    call. = FALSE
  )
}
for (file_name in library_files) {
  source(file.path(work_dir, file_name))
}

# 2. 数据类型和抽样策略
# 数据类型可选："pheno"、"geno"、"pheno_geno"，可单选或多选。
data_types <- c("pheno", "geno", "pheno_geno")

# 抽样策略可选："SVM"、"RF"、"LGBM"，可单选或多选。
strategies <- c("RF")

# 3. 核心种质抽样比例
sample_ratios <- c(0.70)

# 4. 表型-基因型联合权重
# 0.5 表示表型和基因型各占 50%；也可以设置多个权重。
pheno_weights <- c(0.50)
seed <- 123L

valid_data_types <- c("pheno", "geno", "pheno_geno")
valid_strategies <- c("RF")
data_types <- unique(tolower(data_types))
strategies <- unique(toupper(strategies))
if (any(!data_types %in% valid_data_types)) {
  stop("data_types 只能使用 pheno、geno 或 pheno_geno。", call. = FALSE)
}
if (any(!strategies %in% valid_strategies)) {
  stop("strategies 只能使用 SVM、RF 或 LGBM。", call. = FALSE)
}
sample_ratios <- core_validate_ratios(sample_ratios)
pheno_weights <- pg_validate_weights(pheno_weights)

# 5. 运行抽样并输出结果
results <- list()

for (data_type in data_types) {
  for (strategy in strategies) {
    run_name <- paste(data_type, strategy, sep = "_")
    message("正在运行：", run_name)

    result <- switch(
      data_type,
      pheno = build_core_germplasm(
        file_path = pheno_file,
        strategy = strategy,
        sample_ratio = sample_ratios,
        seed = seed,
        id_column = "Taxa"
      ),
      geno = build_genotype_core(
        file_path = geno_file,
        strategy = strategy,
        sample_ratio = sample_ratios,
        seed = seed,
        id_column = "Taxa"
      ),
      pheno_geno = build_pheno_geno_core(
        pheno_file = pheno_file,
        geno_file = geno_file,
        strategy = strategy,
        sample_ratio = sample_ratios,
        pheno_weight = pheno_weights,
        seed = seed,
        pheno_id_column = "Taxa",
        geno_id_column = "Taxa"
      )
    )

    results[[run_name]] <- result
    message("运行完成：", run_name)
  }
}

output_files <- core_export_results(results, output_dir)

cat("\n全部抽样完成。结果保存在：\n", output_dir, "\n\n")
print(unlist(output_files))

