
# ==============================================================================
# 脚本名称: Pheno-Geno_Core_Lib.R
# 功能描述: 整合SVM, RF, LGBM三种策略构建"表型-基因型"联合核心种质
# ==============================================================================

library(caret)
library(e1071) # SVM
library(ranger)# RF
library(lightgbm) # LGBM
library(dplyr)

# --- 辅助函数：计算PIC ---
calc_pic_func <- function(mat) {
  sapply(1:ncol(mat), function(i) {
    freqs <- table(mat[, i]) / nrow(mat)
    pic <- 1 - sum(freqs^2)
    ifelse(is.na(pic), 0, pic)
  })
}

# --- 核心构建函数 ---
  build_pheno_geno_core <- function(pheno_file, geno_file, strategy, sample_ratio, pheno_weight, seed=123){ 
    
  
  genotype_weight <- 1 - pheno_weight
  
  # ========================= Step 1: 数据读取和预处理 =========================
  # 1A. 表型数据
 
  raw_pheno <- read.csv(pheno_file, header = TRUE)
  original_ids <- raw_pheno[, 1] # 假设第一列是ID
  pheno.data <- raw_pheno[, -1]
  
  # 缺失值填充
  pheno.data <- pheno.data %>% mutate(across(where(is.numeric), ~ ifelse(is.na(.), mean(., na.rm = TRUE), .)))
  
  # 标准化
  preprocess_pheno <- preProcess(pheno.data, method = c("center", "scale"))
  pheno_scaled <- as.data.frame(predict(preprocess_pheno, pheno.data))
  
  # 权重得分
  trait_weights <- apply(pheno_scaled, 2, sd)
  weighted_scores <- rowMeans(sweep(pheno_scaled, 2, trait_weights, `*`))
  pheno_scaled$Score <- scale(weighted_scores)
  
  # 1B. 基因型数据
  # 注意：原脚本 read.csv("NP465GD.csv", header = TRUE)[, -c(1,2)]
  # 假设基因型文件行数与表型一致且顺序一致（通常核心种质分析的前提）
  raw_geno <- read.csv(geno_file, header = TRUE)
  geno_data <- raw_geno[, -c(1,2)]
  geno_data <- na.omit(geno_data) # 注意：如果na.omit删除了行，ID对齐会出问题，这里假设无缺失或已对齐
  
  # 如果na.omit确实删了行，这里应该报错或处理，但为保持原脚本逻辑，继续执行
  if(nrow(geno_data) != nrow(pheno.data)) {
    # 简易处理：强制截断以对齐（仅作保护，实际应保证输入数据一致）
    min_rows <- min(nrow(geno_data), nrow(pheno.data))
    geno_data <- geno_data[1:min_rows, ]
    pheno.data <- pheno.data[1:min_rows, ]
    pheno_scaled <- pheno_scaled[1:min_rows, ]
    original_ids <- original_ids[1:min_rows]
  }
  
  preprocess_geno <- preProcess(geno_data, method = c("center", "scale"))
  geno_scaled <- as.data.frame(predict(preprocess_geno, geno_data))
  
  # PIC计算
  PICs <- calc_pic_func(geno_scaled)
  pic_scores <- rowMeans(geno_scaled * PICs)
  geno_scaled$PIC <- scale(pic_scores)
  
  # ========================= Step 2: PCA降维 =========================
  # 表型PCA
  pca_pheno <- prcomp(pheno_scaled[, !(names(pheno_scaled) == "Score")], center = TRUE, scale. = TRUE)
  num_pheno_pc <- which(cumsum(summary(pca_pheno)$importance[2, ]) >= 0.95)[1]
  X_pheno <- as.data.frame(pca_pheno$x[, 1:num_pheno_pc])
  X_pheno$Score <- pheno_scaled$Score
  
  # 基因型PCA
  pca_geno <- prcomp(geno_scaled[, !(names(geno_scaled) == "PIC")], center = TRUE, scale. = TRUE)
  num_geno_pc <- which(cumsum(summary(pca_geno)$importance[2, ]) >= 0.9)[1]
  X_geno <- as.data.frame(pca_geno$x[, 1:num_geno_pc])
  X_geno$PIC <- geno_scaled$PIC
  
  # 数量计算
  num_total <- nrow(X_pheno)
  num_core_total <- round(num_total * sample_ratio)
  num_core_pheno <- round(num_core_total * pheno_weight)
  num_core_pheno <- min(num_core_pheno, num_total) # 防止越界
  num_core_geno <- round(num_core_total * genotype_weight)
  num_core_geno <- min(num_core_geno, nrow(X_geno))
  
  # ================== Step 3: 建模与排序 (策略分支) ==================
  sorted_pheno <- NULL
  sorted_geno <- NULL
  
  if (strategy == "SVM") {
    # --- SVM (原脚本逻辑：使用全量数据训练，Seed=123) ---
    set.seed(seed)
    
    # 表型
    svm_pheno <- train(Score ~ ., data = X_pheno, method = "svmRadial",
                       trControl = trainControl(method = "cv", number = 10),
                       preProcess = NULL, tuneLength = 10)
    pred_pheno <- predict(svm_pheno, newdata = X_pheno)
    sorted_pheno <- order(pred_pheno, decreasing = TRUE)
    
    # 基因型
    svm_geno <- train(PIC ~ ., data = X_geno, method = "svmRadial",
                      trControl = trainControl(method = "cv", number = 10),
                      preProcess = NULL, tuneLength = 10)
    pred_geno <- predict(svm_geno, newdata = X_geno)
    sorted_geno <- order(pred_geno, decreasing = TRUE)
    
  } else if (strategy == "RF") {
    # --- RF (原脚本逻辑：Pheno p=0.9, Geno p=0.7, Seed=123) ---
    set.seed(seed)
    
    # 表型
    trainIndex_pheno <- createDataPartition(X_pheno$Score, p = 0.9, list = FALSE)
    X_train_pheno <- X_pheno[trainIndex_pheno, ]
    rf_pheno <- train(Score ~ ., data = X_train_pheno, method = "ranger",
                      trControl = trainControl(method = "cv", number = 10), tuneLength = 10)
    pred_pheno <- predict(rf_pheno, newdata = X_pheno)
    sorted_pheno <- order(pred_pheno, decreasing = TRUE)
    
    # 基因型
    # 注意：RF脚本中在Pheno和Geno之间没有重置seed，Geno直接接续运行
    trainIndex_geno <- createDataPartition(X_geno$PIC, p = 0.7, list = FALSE)
    X_train_geno <- X_geno[trainIndex_geno, ]
    rf_geno <- train(PIC ~ ., data = X_train_geno, method = "ranger",
                     trControl = trainControl(method = "cv", number = 5), tuneLength = 5)
    pred_geno <- predict(rf_geno, newdata = X_geno)
    sorted_geno <- order(pred_geno, decreasing = TRUE)
    
  } else if (strategy == "LGBM") {
    # --- LGBM (原脚本逻辑：Pheno Seed=123, Geno Seed=456) ---
    set.seed(seed)
    
    # ==== 表型建模 ====
    trainIndex_pheno <- createDataPartition(X_pheno$Score, p = 0.9, list = FALSE)
    X_train_pheno <- X_pheno[trainIndex_pheno, ]
    X_test_pheno <- X_pheno[-trainIndex_pheno, ]
    
    train_features_pheno <- as.matrix(X_train_pheno[, -ncol(X_train_pheno)])
    train_labels_pheno <- X_train_pheno$Score
    test_features_pheno <- as.matrix(X_test_pheno[, -ncol(X_test_pheno)])
    test_labels_pheno <- X_test_pheno$Score
    
    dtrain_pheno <- lgb.Dataset(data = train_features_pheno, label = train_labels_pheno)
    dtest_pheno <- lgb.Dataset(data = test_features_pheno, label = test_labels_pheno, reference = dtrain_pheno)
    
    params_pheno <- list(objective = "regression", metric = "rmse", learning_rate = 0.05,
                         num_leaves = 31, feature_fraction = 0.8, bagging_fraction = 0.8,
                         bagging_freq = 5, min_data_in_leaf = 20, verbosity = -1)
    
    cv_pheno <- lgb.cv(params = params_pheno, data = dtrain_pheno, nfold = 5, nrounds = 500,
                       early_stopping_rounds = 20, eval_freq = 10, verbose = -1)
    
    model_pheno <- lgb.train(params = params_pheno, data = dtrain_pheno, nrounds = cv_pheno$best_iter,
                             valids = list(test = dtest_pheno), eval_freq = 10, verbose = -1)
    
    pred_pheno <- predict(model_pheno, as.matrix(X_pheno[, -ncol(X_pheno)]))
    sorted_pheno <- order(pred_pheno, decreasing = TRUE)
    
    # ==== 基因型建模 (Seed=456) ====
    set.seed(456) # 严格遵循原脚本
    trainIndex_geno <- createDataPartition(X_geno$PIC, p = 0.7, list = FALSE)
    X_train_geno <- X_geno[trainIndex_geno, ]
    X_test_geno <- X_geno[-trainIndex_geno, ]
    
    train_features_geno <- as.matrix(X_train_geno[, -ncol(X_train_geno)])
    train_labels_geno <- X_train_geno$PIC
    test_features_geno <- as.matrix(X_test_geno[, -ncol(X_test_geno)])
    test_labels_geno <- X_test_geno$PIC
    
    dtrain_geno <- lgb.Dataset(data = train_features_geno, label = train_labels_geno)
    dtest_geno <- lgb.Dataset(data = test_features_geno, label = test_labels_geno, reference = dtrain_geno)
    
    params_geno <- list(objective = "regression", metric = "rmse", learning_rate = 0.05,
                        num_leaves = 31, feature_fraction = 0.8, bagging_fraction = 0.8,
                        bagging_freq = 5, min_data_in_leaf = 20, verbosity = -1)
    
    cv_geno <- lgb.cv(params = params_geno, data = dtrain_geno, nfold = 5, nrounds = 500,
                      early_stopping_rounds = 20, eval_freq = 10, verbose = -1)
    
    model_geno <- lgb.train(params = params_geno, data = dtrain_geno, nrounds = cv_geno$best_iter,
                            valids = list(test = dtest_geno), eval_freq = 10, verbose = -1)
    
    pred_geno <- predict(model_geno, as.matrix(X_geno[, -ncol(X_geno)]))
    sorted_geno <- order(pred_geno, decreasing = TRUE)
  }
  
  # ================== Step 4: 核心组筛选 (通用逻辑) ==================
  
  # --- 4A. 表型子集 (高分 + MD最小化) ---
  init_pheno <- max(2, round(num_core_pheno * 0.2))
  core_pheno <- sorted_pheno[1:init_pheno]
  pheno_ncol_idx <- ncol(pheno_scaled) - 1 # 排除最后一列Score
  
  while(length(core_pheno) < num_core_pheno) {
    remain <- setdiff(1:num_total, core_pheno)
    
    # 距离计算
    dist_mat <- as.matrix(dist(rbind(X_pheno[core_pheno, 1:num_pheno_pc, drop=FALSE],
                                     X_pheno[remain, 1:num_pheno_pc, drop=FALSE])))
    sub_dist <- dist_mat[(length(core_pheno)+1):nrow(dist_mat), 1:length(core_pheno), drop=FALSE]
    min_dist <- apply(sub_dist, 1, min)
    
    # 选取距离前10%
    top_percent <- 0.1
    topN <- max(5, round(length(remain) * top_percent))
    top_candidates <- remain[order(min_dist, decreasing = TRUE)[1:topN]]
    
    # MD值计算
    MD_values <- sapply(top_candidates, function(candidate_idx) {
      tmp_core <- c(core_pheno, candidate_idx)
      mean_all <- colMeans(pheno_scaled[, 1:pheno_ncol_idx])
      mean_core <- colMeans(pheno_scaled[tmp_core, 1:pheno_ncol_idx])
      MD_candidate <- mean(abs(mean_core - mean_all) / abs(mean_all)) * 100
      return(MD_candidate)
    })
    
    next_idx <- top_candidates[which.min(MD_values)]
    core_pheno <- c(core_pheno, next_idx)
  }
  
  # --- 4B. 基因型子集 (高分 + 多样性增量) ---
  init_geno <- max(2, round(num_core_geno * 0.2))
  core_geno <- sorted_geno[1:init_geno]
  
  while(length(core_geno) < num_core_geno) {
    remain <- setdiff(1:nrow(X_geno), core_geno)
    
    dist_mat <- as.matrix(dist(rbind(X_geno[core_geno, 1:num_geno_pc], X_geno[remain, 1:num_geno_pc])))
    sub_dist <- dist_mat[(length(core_geno)+1):nrow(dist_mat), 1:length(core_geno), drop=FALSE]
    min_dist <- apply(sub_dist, 1, min)
    
    next_idx <- remain[which.max(min_dist)]
    core_geno <- c(core_geno, next_idx)
  }
  
  # ================== Step 5: 整合与补齐 (St检验) ==================
  core_indices_all <- unique(c(core_pheno, core_geno))
  
  while(length(core_indices_all) < num_core_total) {
    remain <- setdiff(1:num_total, core_indices_all)
    
    # St计算
    St_list <- sapply(remain, function(idx) {
      new_core <- c(core_indices_all, idx)
      St <- 0
      for(j in 1:pheno_ncol_idx) {
        core_vals <- pheno_scaled[new_core, j]
        all_vals <- pheno_scaled[, j]
        ttest <- t.test(core_vals, all_vals)
        if(ttest$p.value < 0.05) St <- St + 1
      }
      return(St)
    })
    
    next_idx <- remain[which.min(St_list)]
    core_indices_all <- c(core_indices_all, next_idx)
  }
  
  # 返回结果
  result <- list(
    row_indices = sort(core_indices_all),
    original_ids = original_ids[sort(core_indices_all)]
  )
  return(result)
  }