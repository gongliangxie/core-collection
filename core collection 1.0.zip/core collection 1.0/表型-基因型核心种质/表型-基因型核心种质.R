# ==============================================================================
# 脚本名称: Run_PhenoGeno_Analysis.R
# 功能描述: 调用工具库，批量执行不同比例和权重的核心种质构建
# ==============================================================================
# 1. 设置参数
setwd("F:/表型-基因型核心种质") # 修改为你的实际路径
pheno_file <- "Phenotype.csv"
geno_file <- "Genotype.csv"

# 2. 加载工具库
lib_file <- "Pheno-Geno_Core_Lib1.0.R"
if(!file.exists(lib_file)) stop("找不到工具库文件，请确认路径！")
source(lib_file) 

# === 核心配置 ===
# 定义要运行的策略
strategies_to_run <- c("SVM")#抽样策略："SVM", "RF", "LGBM"

# 定义抽样比例 (0.1 = 10%, 0.2 = 20%)
ratios_to_run <- c(0.7)

# 定义 表型:基因型 权重配置
# 格式为列表，每个元素为表型权重 (0.1 代表 表型0.1/基因型0.9)
weights_to_run <- c(0.5) 

# 初始化存储
all_results <- list()
max_len <- 0 

# 3. 循环执行任务
cat("========== 开始表型-基因型联合核心种质构建 ==========\n")

for (strat in strategies_to_run) {
  for (ratio in ratios_to_run) {
    for (w_pheno in weights_to_run) {
      
      # 构造列名，例如: SVM_R20_P9G1 (SVM, Ratio 20%, Pheno 0.9, Geno 0.1)
      w_geno <- 1 - w_pheno
      col_name <- sprintf("%s_R%.0f_P%.0fG%.0f", strat, ratio*100, w_pheno*10, w_geno*10)
      
      cat(sprintf(">> 正在运行: %s | 比例: %.2f | 权重(表:基): %.1f:%.1f ... ", 
                  strat, ratio, w_pheno, w_geno))
      
      # 调用核心函数
      res <- build_pheno_geno_core(
        pheno_file = pheno_file,
        geno_file = geno_file,
        strategy = strat,
        sample_ratio = ratio,
        pheno_weight = w_pheno,
        seed = 123
      )
      
      # 存储结果
      all_results[[col_name]] <- res$original_ids
      
      if (length(res$original_ids) > max_len) {
        max_len <- length(res$original_ids)
      }
      
      cat("完成! (选出", length(res$original_ids), "个)\n")
    }
  }
}

# 4. 导出结果到CSV
result_df <- data.frame(matrix(ncol = length(all_results), nrow = max_len))
colnames(result_df) <- names(all_results)

for (name in names(all_results)) {
  ids <- all_results[[name]]
  ids_padded <- c(ids, rep(NA, max_len - length(ids)))
  result_df[[name]] <- ids_padded
}

output_filename <- paste0("0.5_PhenoGeno-SVM", format(Sys.time(), "%Y%m%d_%H%M"), ".csv")
write.csv(result_df, output_filename, row.names = FALSE, na = "")

cat("\n========== 全部完成 ==========\n")
cat("结果已保存至:", output_filename, "\n")
