# ==============================================================================
# 工具库脚本名称: Genotype_Core_Lib.R
# 功能描述: 整合 SVM 3.0 (预测排序法), RF, LGBM 策略
# 优化重点: 恢复 SVM 预测排序逻辑，解决近交系数负值问题
# ==============================================================================

library(caret)
library(e1071)    
library(ranger)   
library(lightgbm) 
library(dplyr)
library(data.table)

# --- 1. PIC 计算函数 (严格复刻 TXT 脚本逻辑) ---
calculate_PIC_func <- function(genotype_matrix) {
  n_loci <- ncol(genotype_matrix)
  PIC_values <- numeric(n_loci)
  genotype_matrix <- as.matrix(genotype_matrix)
  
  for (i in 1:n_loci) {
    # 使用 TXT 原版逻辑：计算等位基因频率
    allele_freqs <- table(genotype_matrix[, i]) / nrow(genotype_matrix)
    PIC <- 1 - sum(allele_freqs^2)
    
    if (is.nan(PIC) || is.na(PIC)) {
      PIC <- 0
    }
    PIC_values[i] <- PIC
  }
  return(PIC_values)
}

# --- 2. 核心构建函数 ---
build_genotype_core <- function(file_path, strategy = "SVM", sample_ratio = 0.2, seed = 123) {
  
  # ================= Step 1: 数据加载与预处理 =================
  # 读取 Run Script 预处理后的临时文件 (第一列为样本名)
  raw_data <- read.csv(file_path, header = TRUE, row.names = 1, check.names = FALSE)
  original_ids <- rownames(raw_data)
  
  # 强制转为数值矩阵并恢复 ID
  data_genotype <- as.data.frame(lapply(raw_data, as.numeric))
  rownames(data_genotype) <- original_ids
  
  # 数据归一化 (Center + Scale)
  preprocess <- preProcess(data_genotype, method = c("center", "scale"))
  data_scaled <- predict(preprocess, data_genotype)
  
  # 计算 PIC 权重与样本得分
  PIC_values <- calculate_PIC_func(data_scaled)
  
  # 【逻辑恢复】：使用 TXT 脚本的“循环回收”矩阵相乘法，确保遗传参数稳定
  pic_sample_values <- rowMeans(as.matrix(data_scaled) * PIC_values, na.rm = TRUE)
  
  # PCA 降维 (保留 90% 变异)
  pca_result <- prcomp(as.matrix(data_scaled), center = TRUE, scale. = TRUE)
  explained_var <- summary(pca_result)$importance[2, ]
  num_components <- which(cumsum(explained_var) >= 0.90)[1]
  
  X_pca <- as.data.frame(pca_result$x[, 1:num_components])
  X_pca$PIC <- scale(pic_sample_values) # 将 Target 标准化
  
  X_all_pca_features <- as.matrix(X_pca[, -ncol(X_pca)])
  
  sorted_indices <- NULL
  
  # ================= Step 2: 策略分支 =================
  
  if (strategy == "SVM") {
    # --- SVM 3.0 策略: 纯预测排序法 ---
    set.seed(seed)
    trainIndex <- createDataPartition(X_pca$PIC, p = 0.7, list = FALSE)
    X_train <- as.matrix(X_pca[trainIndex, -ncol(X_pca)])
    y_train <- as.numeric(X_pca$PIC[trainIndex])
    
    # 交叉验证调参训练
    svm_tune <- train(
      x = X_train, y = y_train,
      method = "svmRadial",
      tuneLength = 10,
      trControl = trainControl(method = "cv", number = 5)
    )
    
    # 对所有样本进行预测
    y_all_pred <- predict(svm_tune, X_all_pca_features)
    
    # 【核心修改】：直接按预测值降序排序，不引入多样性权重 (Alpha)
    sorted_indices <- order(y_all_pred, decreasing = TRUE)
    
  } else if (strategy == "RF") {
    # --- RF 策略 ---
    set.seed(seed)
    trainIndex <- createDataPartition(X_pca$PIC, p = 0.9, list = FALSE) 
    X_train <- X_pca[trainIndex, ]
    
    set.seed(seed) 
    rf_model <- train(
      PIC ~ ., data = X_train,
      method = "ranger",
      trControl = trainControl(method = "cv", number = 10),
      tuneLength = 10,
      importance = "permutation"
    )
    
    y_all_pred <- predict(rf_model, newdata = X_pca[, -ncol(X_pca)])
    sorted_indices <- order(y_all_pred, decreasing = TRUE)
    
  } else if (strategy == "LGBM") {
    # --- LGBM 策略 ---
    set.seed(seed)
    trainIndex <- createDataPartition(X_pca$PIC, p = 0.7, list = FALSE)
    train_data_subset <- X_pca[trainIndex, ]
    
    train_features <- as.matrix(train_data_subset[, -ncol(train_data_subset)])
    train_labels <- train_data_subset$PIC
    
    dtrain <- lgb.Dataset(data = train_features, label = train_labels)
    
    params <- list(objective = "regression", metric = "rmse", learning_rate = 0.02, verbosity = -1)
    cv_results <- lgb.cv(params = params, data = dtrain, nrounds = 500, nfold = 5, 
                         early_stopping_rounds = 20, verbose = -1)
    
    model <- lgb.train(params = params, data = dtrain, nrounds = cv_results$best_iter)
    
    y_all_pred <- predict(model, X_all_pca_features)
    sorted_indices <- order(y_all_pred, decreasing = TRUE)
  }
  
  # ================= Step 3: 截取并返回 =================
  num_samples <- max(2, round(nrow(data_genotype) * sample_ratio))
  core_indices <- sorted_indices[1:num_samples]
  
  return(list(
    original_ids = original_ids[core_indices]
  ))
}