# ==============================================================================
# 脚本名称: Run_Genotype_Analysis.R
# 功能描述: 使用样本名作为ID进行核心种质抽样并导出
# ==============================================================================

# 1. 加载工具库
setwd("F:/基因型核心种质")

lib_file <- "Genotype_Core_Lib1.0.R" 
if(!file.exists(lib_file)) stop("找不到工具库文件，请确认路径！")
source(lib_file) 

# 2. 数据预处理：将第二列设为行名
data_file <- "Genotype.csv"

# 临时读取数据以处理 ID
temp_data <- read.csv(data_file, header = TRUE, stringsAsFactors = FALSE)

# 关键步骤：将第二列作为行名 (确保 ID 唯一)
# 假设第二列是样本名，从第三列开始是基因型数据
rownames(temp_data) <- temp_data[, 2]
processed_data <- temp_data[, -c(1, 2)] # 移除前两列（行号列和原ID列）

# 将处理后的数据写回一个临时文件，供库函数调用（如果库函数只接受路径）
# 如果库函数 build_genotype_core 支持直接传入 data.frame，建议直接传入 processed_data
write.csv(processed_data, "temp_geno_for_analysis.csv", row.names = TRUE)

# 3. 设置参数
strategies_to_run <- c("RF")#抽样策略："SVM", "RF", "LGBM"
ratios_to_run <- c( 0.70)

all_results <- list()
max_len <- 0 

# 4. 循环执行
cat("========== 开始基因型核心种质构建 (样本名模式) ==========\n")

for (strat in strategies_to_run) {
  for (ratio in ratios_to_run) {
    
    cat(sprintf(">> 正在运行策略: %s | 抽样比例: %.2f ... ", strat, ratio))
    
    # 调用核心函数 (使用包含样本名的临时文件)
    # 只要 build_genotype_core 内部使用了 rownames() 提取 ID，输出就是样本名
    res <- build_genotype_core("temp_geno_for_analysis.csv", strategy = strat, sample_ratio = ratio, seed = 123)
    
    # 此时 res$original_ids 应该是字符串格式的样本名
    selected_ids <- as.character(res$original_ids)
    
    col_name <- paste0(strat, "_", ratio * 100)
    all_results[[col_name]] <- selected_ids
    
    if (length(selected_ids) > max_len) {
      max_len <- length(selected_ids)
    }
    
    cat("完成! (选出", length(selected_ids), "个)\n")
  }
}

# 5. 导出结果到CSV
result_df <- data.frame(matrix(ncol = length(all_results), nrow = max_len))
colnames(result_df) <- names(all_results)

for (name in names(all_results)) {
  ids <- all_results[[name]]
  ids_padded <- c(ids, rep(NA, max_len - length(ids))) 
  result_df[[name]] <- ids_padded
}

output_filename <- paste0("Geno_RF", ".csv")
write.csv(result_df, output_filename, row.names = FALSE, na = "")

# 清理临时文件
if(file.exists("temp_geno_for_analysis.csv")) file.remove("temp_geno_for_analysis.csv")

cat("\n========== 全部完成 ==========\n")
cat("结果已保存至:", output_filename, "\n")